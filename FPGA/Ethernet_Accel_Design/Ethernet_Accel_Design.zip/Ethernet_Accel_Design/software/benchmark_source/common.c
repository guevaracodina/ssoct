
// This is a global variable used to short-circuit the test
int DONE;

